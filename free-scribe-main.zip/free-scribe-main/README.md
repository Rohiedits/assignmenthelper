# free-scribe
 React web based transcription & translation app that uses web workers to run ML models in the browser
